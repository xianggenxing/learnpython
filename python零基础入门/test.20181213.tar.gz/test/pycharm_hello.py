"""

pycharm hello
@Author work

"""

# idx is number
idx = 0

while idx <= 100:
    # print 偶数
    if idx % 2 == 0:
        print(idx, "hello", 123)
    idx += 1

