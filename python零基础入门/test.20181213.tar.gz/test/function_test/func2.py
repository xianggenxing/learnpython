
def sum(a, b):
    """
    计算变量的和
    :param a:
    :param b:
    :return:
    """
    return a+b

print(sum(1,2))
print(sum(2,3))
print(sum(3,4))