
def get_info(sid):
    return 123, 'xiaoming', 20

sid,sname,sage = get_info(123)
print(sid,sname,sage)

print(type(get_info(123)))