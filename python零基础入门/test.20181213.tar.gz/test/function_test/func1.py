def print_hello():
    print("""
        欢迎来到本网站.
    """)

print_hello()