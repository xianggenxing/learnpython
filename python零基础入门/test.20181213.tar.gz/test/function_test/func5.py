
def func(list):
    list.extend([1,2,3])


l = [11,12,13]
print(l)
func(l)
print(l)