import pya

print("in pyb.py", __name__)