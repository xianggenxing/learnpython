
from module01.module02.module03 import utils

utils.say_hello()
