sql = open("bigsql.sql").read()

print(sql)