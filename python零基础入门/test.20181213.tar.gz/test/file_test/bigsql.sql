select *
from table
where id > 123
order by id;